const adduserbtn=document.getElementById('adduser');
const btnText=adduserbtn.innerText;
const userfield=document.getElementById('username');
const record=document.getElementById('records');

let userArray=[];
let edit_id=null;

let objstr=localStorage.getItem('users');  //getting the data from local storage

if(objstr!=null){
    userArray=JSON.parse(objstr);
}
displayinfo();
adduserbtn.onclick=(e)=>{
    const name=userfield.value;
    if(edit_id!=null){
        //edit
        userArray.splice(edit_id,1,{'name':name});
        edit_id=null;
    }
    else{
        //insert
     
    userArray.push({'name':name});
    }
    
    saveinfo(userArray);
    userfield.value= '';
  
    adduserbtn.innerHTML=btnText;

}

function saveinfo(userArray){
    let str=JSON.stringify(userArray);
    localStorage.setItem("users",str);
    displayinfo();

}
function displayinfo(){
    let statement='';
    userArray.forEach((user,i) =>{
        statement+= `<tr>
        <th scope="row">${i+1}</th>
        <td>${user.name}</td>
        <td><i class="btn text-white fa fa-edit btn-info mx-3" onclick='editinfo(${i})' ></i>&nbsp;&nbsp;&nbsp;&nbsp;<i class="btn btn-danger text-white fa fa-trash" onclick='deleteinfo(${i})'></i></td>
      </tr>`;    
    });
    record.innerHTML=statement;
    
}
function editinfo(id){
    edit_id=id;
    userfield.value=userArray[id].name;
    adduserbtn.innerText='Save Changes';

    
}
function deleteinfo(id){
   userArray.splice(id,1);
   saveinfo(userArray);
   
    
}